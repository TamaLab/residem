# Table of Contents

1. [About](#About)
2. [Installation](#Installation)
3. [Usage](#Usage)
4. [License](#License)
5. [Contact](#Contact)

---

# Resi-DEM.

Resi-DEM is a tool that identifies residues in isomorphous difference density map captured using Time-resolved serial femtosecond crystallographic data. It used DBSCAN based clustering algorithm to cluster the co-ordinates of the difference peak in the difference density map and assigns the cluster to the neighbouring atoms. This tool also calculates the occupancy of the triggered state population using structure factor extrapolation method suggested by Genick et al.

### Workflow and command line argument for running the tool.


1.  The `master.py` requires the followig arguments:

    1.  `-p|--phil` or parameter file to provide all the necessary input files for calculations. A default phil files is diven in the folder that can be modified as input data.
        A default phil can be generated using the following command.

            ~~~bash
            residem -d
            ~~~

    2.  Alternatively the command line option can be provided

        1. A refernce pdb has to be provieded

        - `-r | --ref` a refernce pdb

        2. Two mtz has to be provided, one is refernce state and triggered state

        - `-m | mtz` corresponding to refernce mtz and
        - `-t | tmtz` corresponding to the triggered state mtz

        3. `-hi | --high` and `-l | --low` high and low resolution of cutoff of the map, if not given a default value for the exisiting refernce and triggered state will be calculate and the commom minima for higher resolution and common maxima for higher resolution will be taken as resolution cutoff.
        4. `-rl | --refl ` and `-tl | --tril` are the inputs fot the reference and triggred mtz observed structure factors. A default structure factor labels will be taken if not provided, the default label taken as `FP,SIGFP`. Also refernce data should be refined and the refernce mtz should cointain details about the calculated structure factor with labels `'FC,PHIC' or 'FC_ALL,PHIC_ALL' or 'FC,PHIFC'` if not it will be calcualted.
        5. `-s | --sigma ` sigma cutoff of the map for map analysis, with the default cutoff value of 3.0 RMSD

        6. `-x | -max` radius of residues to be selected with in the density. default is 2.0 $\AA$
        7. `-c | --method` method for selection map for occupancy estimation.

The typical input for command line are:

1. ```bash
   residem - p Resmap.phil
   ```
2. ```bash
   residem -r 5b6v.pdb  -m 5b6v.mtz -t 5b6x.mtz -hi 2.0 -l 20.0 -rl "FP,SIGFP" -s 3.0 -c cluster
   ```
3. ```bash
   # only calculation of the differnce map.
   residem -r 5b6v.pdb  -m 5b6v.mtz -t 5b6x.mtz
   # If occupancy has to be estimated
   residem -r 5b6v.pdb -m 5b6v.mtz -t 5b6z_phases.mtz -o True
   ```

4. Two weighting scheme can be added, [ursby](https://onlinelibrary.wiley.com/doi/epdf/10.1107/S0108767397004522?sentby=iucr) or [ren](https://pubs.acs.org/doi/full/10.1021/bi0107142) as provided in the paper.

```bash

    residem -r 5b6v.pdb -m 5b6v.mtz -t 5b6z_phases.mtz -o True -w ursby
    # or
    residem -r 5b6v.pdb -m 5b6v.mtz -t 5b6z_phases.mtz -o True -w ren
```

---

```mermaid
flowchart TD;
    input <--- text(Reference pdb, \n reference,triggered mtz);
    input --> master;
    master-->scaling;
    scaling--> output(ccp4 maps with different weights);
    scaling--> |selected-weight\n None or ren or ursby|differnce-map(Differnce map calculation \n for occupancy estimation);
    output--> |selected-weight\n None or ren or ursby| residue(Clustering denisty and estimating residues)
    differnce-map--> occupancy(Generating differnt map Coefficients)
    residue --> residuelist(List of residues with electron density parameters \n choosing the cluster number and the data points)
```

### Running the master file from command line argument##

---

```python
from master import run
mp_run = run("5b6v.pdb","5b6v.mtz","5b6x.mtz","FP,SIGFP","FP,SIGFP",None,None,3.0,2.0,None,None)
```

## Installation
Installation of cctbx package

1. Creating a conda virtual environemt:

```bash
# you can change the name if you want
conda create -n residem python=3.7 -f env.yaml --prune
```

2. Activation of conda environment

```bash
conda activate residem
```

3. pip install the residem-0.1.0.tar.gz

```bash
pip install dist/residem-0.1.0.tar.gz
```

4. To uninstall the package :

```
pip uninstall residem
```

# Usage

Some of the command line usage of the tool is as shown below:

```bash
# To download pdb and mtz
$ residem_pdb_mtz 5b6v
# To run resi-DEM globally
$ residem -r 5b6v.pdb -m 5b6v.mtz -t 5b6w.mtz -o True --scale aniso/iso -w ursby/ren/hekstra/default/ -a atom/residue -p True/ False -n 216 -s 3.0
# To visualize the difference density in coot
$ residem_coot -r 5b6v -m F_obs_minus_F_obs.ccp4
# To extract map around model incase want to proceed on with map based SVD analysis
$ residem_extract_around_model -r 5b6v -m F_obs_minus_F_obs.ccp4 -s "resseq 182:214" -d 5.0 -b 5.0 -o output
# To generate map coefficient from model and mtz for comparison with difference density map, any of the "2mFo-Dfc/mFo-DFc/2Fo-Fc/mFo-Fc/mFo/Fo" map coefficient can be selected
$ residem_mtz2map -r 5b6v.pdb -m 5b6v.mtz -l 'FP,SIGFP' -t  mFo-DFc -o output
# To analyze cluster based SVD for variation in electron density.
$ residem_svd_csv -r 5b6b.pdb -f *.csv -i 10 -n 182,216-218,300 -d CA/SC/CM -t density/peak -cmap Spectral
# To run map based SVD analysis
$ residem_svd_map -r 5b6v.pdb -f *.ccp4 -s 2 -resi 'resseq 182 or resseq 214:216 or resseq 300'
# To generate a pymol image with isomorphous difference density map
$  residem_pymol_image -r 5b6v.pdb -m FO-FO.ccp4 -resi 'resi 182+216+300' -all/-p/-n  True -o output_all -s 3.0 -c 1.6
# To generate image to compare how reference and triggered state varies using pymol
$ residem_pymol_alt_viz -r1 5b6x.pdb  -r2 MD1.pdb -m1 2FO-Fc.ccp4 -m2 FO-FO.ccp4 -resi 'resi 182+216+300' -o output_all -s 3.0
# saving pdb based on selected residue as alternative conformer and setting the occupancy of the selected residue.
$ residem_pdb_alt_save -r 5b6v.pdb -n "182,216-218,300" -c A -o 30/0.30 -f merged
#
```

# License
Residem is an open-source tool available under the MIT License, providing users with the freedom to use, modify, and distribute the software. Additionally, Residem incorporates adapted modules from the Computational Crystallography Toolbox (cctbx), and users are advised to also refer to the cctbx license to comply with its terms and conditions. 

# Contact
* Sriram Srinivasa Raghavan : hypowergravity@gmail.com, sriram.srinivasaraghavan@riken.jp
* Osamu Miyashita : osamu.miyashita@riken.jp
