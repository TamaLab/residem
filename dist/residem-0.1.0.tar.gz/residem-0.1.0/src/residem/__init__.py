""" This is a package to estimate the occupancy of map for time resolved serial femtosecond crystallography """


__version__ = "0.1.0"