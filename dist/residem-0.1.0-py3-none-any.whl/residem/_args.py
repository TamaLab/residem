""" This has the description of the residem command line arguments"""



residem_overview = (f""" `residem `is an command line which computes the isomorphous difference density (DED) maps. You will need 
to provide one reference pdb along with mtz file of reference and triggered system The input can be intensity profiles 
or structure factor amplitudes which which the programs try to detects the labels associated with intensity profiles 
or structure factor amplitudes, if not label for reflection files has to be supplemented. Then the ResiDEM perfoms 
scaling of the reference and triggered structure factors followed by calculation of difference struture factor and DED 
maps.
""")

residem_pdb_mtz_overview = (""" `residem_pdb_mtz` is an command line utility which can be used to download pdb and mtz from https://www.rcsb.org/.
""")

residem_coot_overview = (""" `residem_coot` is an command line utility which can be used to visualize the DED maps. It is just uses 
coot --scripts to load an additional script to view the residues associated to DED maps.  It just calls coot and provides, 
input script for residual tracking associated to DED maps. 
""")
residem_extract_around_model_overview = ("""`residem_extract_around_model` is an command line utility which can be used to extract 
map around the specified residue in map. 
""")
residem_svd_csv_overview = (""" `residem_svd_csv` is an command line utility which can be used to analyze the results of 
difference density output. The utility can plot one dimensional residue wise plot, two dimensional heat map plot, 
Pearson correlation plot and network plot for residue with difference density in DED maps. 
""")

residem_pymol_image_overview = (f""" `residem_pymol_image` is an command line utility which can be used to
 generate image of residue in DED maps using pymol.
""")


residem_args = (
    (("--phil", "-p"), {
        "nargs": 1,
        "required": True,
        "help": (""" phil file is Python Hierarchial Input Language file, containing all inputs can be given to run the 
        residem command line utility with one argument
        """
        ),
    }),

    (("-d", "--default" ), {
        "nargs": 1,
        "metavar": None,
        "required": False,
        "help": ( """ it will print a default phil file which can be modified and provided as input. 
        """
        ),
    }),

    (("--pdboff", "-p"), {
        "nargs": 1,
        "metavar": None,
        "required": True,
        "help": (
            "Reference PDB or mmCIF corresponding to the off/apo/ground/dark state. "
            "Used for rigid-body refinement of both input MTZs to generate phases."
        ),
    }),
    (("--ref", "-r"), {
        "nargs": 1,
        "metavar": None,
        "required": True,
        "help": (
            "Reference PDB to generate phases and other calculations such as scaling,figure of merit, phase error etc.."
        ),
    }),
    (("--mtz", "-m"), {
        "nargs": 1,
        "metavar": None,
        "required": True,
        "help": (
            "Refined reference mtz with experimental observed intensity or structure factors, it should also have FC,PHIC columns"
        ),
    }),
    (("--tmtz", "-t"), {
        "nargs": 1,
        "metavar": None,
        "required": True,
        "help": (
            "Triggered mtz with experimental observed intensity or structure factors."
        ),
    }),

    (("--high", "-hi"), {
        "nargs": 1,
        "metavar": None,
        "required": False,
        "help": (
            "High resolution cutoff, by default highest common resolution between the reference and triggered structure factor is taken"
        ),
    }),
    (("--low ", "-l"), {
        "nargs": 1,
        "metavar": None,
        "required": False,
        "help": (
            "Low resolution cutoff, by default highest common resolution between the reference and triggered structure factor is taken"
        ),
    }),
    (("--refl", "-rl"), {
        "nargs": 1,
        "metavar": None,
        "required": False,
        "help": (
            """Label of structure factor or intensity of reference mtz to be taken for processing. By default it identifies 
            from the following labels 'FP,SIGFP' or 'F,SIGF' or 'F-obs-filtered,SIGF-obs-filtered' or 'I-obs,SIGI-obs' or 'I,SIGI'. 
            If not column label has to provided. """
        ),
    }),
    (("--tril", "-tl"), {
        "nargs": 1,
        "metavar": None,
        "required": False,
        "help": (
            """Label of structure factor or intensity of triggered mtz to be taken for processing. By default it identifies 
            from the following labels 'FP,SIGFP' or 'F,SIGF' or 'F-obs-filtered,SIGF-obs-filtered' or 'I-obs,SIGI-obs' or 'I,SIGI'. 
            If not column label has to provided. """
        ),
    }),
    ((" --fcalclabel", "-fl"), {
        "nargs": 1,
        "metavar": None,
        "required": False,
        "help": (
            """Label of calculated structure factor and phase of reference mtz to be taken for processing. By default it identifies 
            from the following labels 'FC,PHIC' or 'FC_ALL,PHIC_ALL' or  'FC,PHIFC' or "F-model,PHIF-model". 
            If not column label has to provided. """
        ),
    }),
    ((" --sigma", "-s"), {
        "nargs": 1,
        "metavar": None,
        "required": False,
        "help": (
            """ Sigma cutoff for data processing by default it is 3.0 sigma """
        ),
    }),
    ((" --weight", "-w"), {
        "nargs": 1,
        "metavar": None,
        "required": False,
        "help": (
            """ Weighting scheme for treatment of noise in DED maps """
        ),
    }),
    ((" --alpha", "-ws"), {
        "nargs": 1,
        "metavar": None,
        "required": False,
        "help": (
            """ Alpha for modified ren  weight, alpha =0.05 for hekstra, alpha =1 for schmidt weighting scheme """
        ),
    }),
    (("--scale"), {
        "required": False,
        "default": None,
        "nargs": "*",
        "help": (
            """Scaling of structure factors between triggered and reference system before generation of
             difference structure factor and D$ED maps. It can isotropic or anisotropic scaling or no scaling if the 
             structure factors are already scaled """
        ),
    }),
    (("--atom_profile", "-v"), {
        "nargs": 1,
        "metavar": None,
        "required": False,
        "help": (
            """ One dimenstional atom wise representation of difference density, based on max or mean peaks around atom profile.By default its mean """
        ),
    }),

    (("--scaling_method", "-sm"), {
        "nargs": 1,
        "metavar": None,
        "required": False,
        "help": (
            """  Scaling method using methods implemented using cctbx or ccp4 based program. """
        ),
    }),
    (("--ccp4_scaling_method", "-cs"), {
        "nargs": 1,
        "metavar": None,
        "required": False,
        "help": (
            """  If Scaling method is selected using ccp4 based program. Linear scaling can be chosen by default, if ccp4 method is selected.  """
        ),
    }),
)


residem_pdb_mtz_overview_args =  (
    (("--ref", "-r"), {
        "nargs": 1,
        "required": True,
        "help": (""" Pdb id to be downloaded in lower case. Example 5b6v"""
        ),
    }),
)


residem_coot_args = (
    (("--ref", "-r"), {
        "nargs": 1,
        "required": True,
        "help": (""" Reference pdb taken for model visualization """
        ),
    }),
    (("--map", "-m"), {
        "nargs": 1,
        "required": True,
        "help": (""" Isomorphous difference density (DED) map taken for visualization """
                 ),
    }),
)

residem_extract_around_model_args = (
    (("--pdb", "-r"), {
        "nargs": 1,
        "required": True,
        "help": (""" Reference pdb taken for mask calculation """
        ),
    }),
    (("--map", "-m"), {
        "nargs": 1,
        "required": True,
        "help": (""" Isomorphous difference density (DED) map for masking in ccp4 format """
                 ),
    }),
    (("--selection", "-s"), {
        "nargs": 1,
        "required": True,
        "help": (""" Residue selection for masking the DED map. Phenix/cctbx atom naming to be given as input.
        Example: 'resseq 182:214' """
                 ),
    }),
    (("--radius", "-r"), {
        "nargs": 1,
        "required": False,
        "help": (""" Radius around the residue the map has to truncated, by default 5 Å is used . """
                 ),
    }),
    (("--box", "-b"), {
        "nargs": 1,
        "required": False,
        "help": (""" Box cushion around the residue the map has to truncated, by default 5 Å is used . """
                 ),
    }),
    (("--output", "-o"), {
        "nargs": 1,
        "required": False,
        "help": (""" Output name of the truncated map. """
                 ),
    }),
)

residem_svd_csv_args = (
    (("--file", "-f"), {
        "nargs": 1,
        "required": True,
        "help": (""" Files for which analysis has to done. List of files can be given or if all the files are in 
        same folder "*.csv" can be given as input """
        ),
    }),
    (("--cmap", "-c"), {
        "nargs": 1,
        "required": True,
        "help": (""" Matplotlib cmap colour for plotting. By default it is Spectral. More can be found 
        in https://matplotlib.org/stable/users/explain/colors/colormaps.html """
                 ),
    }),
    (("--ncmap", "-s"), {
        "nargs": 1,
        "required": True,
        "help": (""" Network cmap colour  """
                 ),
    }),
    (("--radius", "-r"), {
        "nargs": 1,
        "required": False,
        "help": (""" Radius around the residue the map has to truncated, by default 5 Å is used . """
                 ),
    }),
    (("--box", "-b"), {
        "nargs": 1,
        "required": False,
        "help": (""" Box cushion around the residue the map has to truncated, by default 5 Å is used . """
                 ),
    }),
    (("--output", "-o"), {
        "nargs": 1,
        "required": False,
        "help": (""" Output name of the truncated map. """
                 ),
    }),
)



common_args = (
    # args used by all three utilities
    (("--ligands", "-l"), {
        "help": "Any .cif restraint files needed for refinement",
        "required": False,
        "default": None,
        "nargs": "*",
    }),

    (("--input-dir", "-i"), {
        "help": "Path to input files. Optional, defaults to './' (current directory)",
        "required": False,
        "default": "./",
    }),

    (("--output-dir", "-o"), {
        "help": "Path to which output files should be written. Optional, defaults to './' (current directory)",
        "required": False,
        "default": "./",
    }),

    (("--spacing", "-s"), {
        "help": (
            "Approximate voxel size in Angstroms for real-space maps. Defaults to 0.5 A. "
            "Value is approximate because there must be an integer number of voxels along each unit cell dimension"
        ),
        "required": False,
        "default": 0.5,
        "type": float,
    }),

    (("--dmin",), {
        "help": (
            "Highest-resolution (in Angstroms) reflections to include in Fourier transform for FloatGrid creation. "
            "By default, cutoff is the resolution limit of the lower-resolution input MTZ. "
        ),
        "required": False,
        "type": float,
        "default": None,
    }),

    (("--no-bss",), {
        "help": (
            "Include this flag to skip bulk solvent scaling in phenix.refine. By default, BSS is included."
        ),
        "required": False,
        "action": "store_true",
        "default": False,
    }),

    (("--verbose", "-v"), {
        "help": "Include this flag to print out scaleit and phenix.refine outputs to the terminal. Useful for troubleshooting, but annoying; defaults to False.",
        "required": False,
        "action": "store_true",
        "default": False,
    }),

    (("--eff",), {
        "help": "Custom .eff template for running phenix.refine. ",
        "required": False,
        "default": None,
    }),

    (("--keep-temp-files", "-k"), {
        "required": False,
        "default": None,
        "help": (
            "Do not delete intermediate matchmaps files, but rather place them in the supplied directory. "
            "This directory is created as a subdirectory of the supplied output-dir."
        )}),

    (("--script",), {
        "required": False,
        "default": "run_matchmaps",
        "help": (
            "Name for a file {script}.sh which can be run to repeat this command. "
            "By default, this file is called `run_matchmaps.sh`. "
            "Note that this file is written out in the current working directory, NOT the input or output directories"
        )
    }),

    (("--phenix-version",), {
        "required": False,
        "help": (
            "Specify phenix version as a string, e.g. '1.20'. "
            "If omitted, matchmaps will attempt to automatically detect the version in use "
            "by analyzing the output of phenix.version"
        )
    }),
)
